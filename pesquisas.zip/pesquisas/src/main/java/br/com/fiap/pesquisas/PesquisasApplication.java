package br.com.fiap.pesquisas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PesquisasApplication {

    public static void main(String[] args) {
        SpringApplication.run(PesquisasApplication.class, args);
    }

}
